Sound pack downloaded from Freesound
----------------------------------------

"Ice Foley"

This pack of sounds contains sounds by the following user:
 - ecfike ( https://freesound.org/people/ecfike/ )

You can find this pack online at: https://freesound.org/people/ecfike/packs/11149/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 177410__ecfike__large-object-fall-through-ice.wav
    * url: https://freesound.org/s/177410/
    * license: Creative Commons 0
  * 177225__ecfike__ice-hit-8.wav
    * url: https://freesound.org/s/177225/
    * license: Creative Commons 0
  * 177224__ecfike__ice-hit-7.wav
    * url: https://freesound.org/s/177224/
    * license: Creative Commons 0
  * 177223__ecfike__ice-crack-9.wav
    * url: https://freesound.org/s/177223/
    * license: Creative Commons 0
  * 177222__ecfike__ice-hit-1.wav
    * url: https://freesound.org/s/177222/
    * license: Creative Commons 0
  * 177221__ecfike__ice-hit-8.wav
    * url: https://freesound.org/s/177221/
    * license: Creative Commons 0
  * 177220__ecfike__ice-hit-7.wav
    * url: https://freesound.org/s/177220/
    * license: Creative Commons 0
  * 177219__ecfike__ice-crack-9.wav
    * url: https://freesound.org/s/177219/
    * license: Creative Commons 0
  * 177218__ecfike__ice-hit-1.wav
    * url: https://freesound.org/s/177218/
    * license: Creative Commons 0
  * 177217__ecfike__ice-crack-5.wav
    * url: https://freesound.org/s/177217/
    * license: Creative Commons 0
  * 177216__ecfike__ice-crack-6.wav
    * url: https://freesound.org/s/177216/
    * license: Creative Commons 0
  * 177215__ecfike__ice-crack-7.wav
    * url: https://freesound.org/s/177215/
    * license: Creative Commons 0
  * 177214__ecfike__ice-crack-8.wav
    * url: https://freesound.org/s/177214/
    * license: Creative Commons 0
  * 177213__ecfike__ice-crack-1.wav
    * url: https://freesound.org/s/177213/
    * license: Creative Commons 0
  * 177212__ecfike__ice-crack-2.wav
    * url: https://freesound.org/s/177212/
    * license: Creative Commons 0
  * 177211__ecfike__ice-crack-3.wav
    * url: https://freesound.org/s/177211/
    * license: Creative Commons 0
  * 177210__ecfike__ice-crack-4.wav
    * url: https://freesound.org/s/177210/
    * license: Creative Commons 0


